<?php

class Login extends MX_Controller {

	function __construct()
	{
		$this->load->helper('url');
		$this->output->set_common_meta('Login', 'Login usuarios', 'Login');
        $this->output->set_template('default');
	}
	
	function index()
	{
		/*$data['main_content'] = 'login_form';
		$this->load->view('includes/template', $data);	*/	
		if($this->is_logged_in() && modules::run('admin/is_admin') )
		{
			redirect('admin');
		}
		else if($this->is_logged_in() && !modules::run('admin/is_admin'))
		{
			redirect('site/members_area');
		}
		else
		{
			$this->load->view('login_form');	
		}
			
	}
	
	function validate_credentials()
	{		

		$data['error'] = '';
		$this->load->library('form_validation');

	    $this->form_validation->set_rules('dni', 'DNI', 'required');
	    $this->form_validation->set_rules('password', 'Password', 'required');


	    if($this->form_validation->run() !== FALSE)
    	{
			$this->load->model('usuarios_model');
			$query = $this->usuarios_model->validate();
		
			if($query) // if the user's credentials validated...
			{
				$name = $this->usuarios_model->get_name($this->input->post('dni'));
				$data = array(
					'dni' => $this->input->post('dni'),
					'is_logged_in' => true,
					'name' => $name,
				);

				if(is_numeric($query))
				{
					$data['is_admin'] = true;
					$this->session->set_userdata($data);
					redirect('admin');
				}
				else
				{
					$this->session->set_userdata($data);
					redirect('site/members_area');
				}

				
				
			}
			else // incorrect username or password
			{

				$this->load->view('login_form');
			}
		}
		else // incorrect username or password
		{
			$data['error'] = 'DNI o Password incorrectos';
			$this->load->view('login_form',$data);
		}


	}	
	
	function signup()
	{
		/*$data['main_content'] = 'signup_form';
		$this->load->view('includes/template', $data);*/
		$this->load->view('signup_form');
	}

	function forgot_pass()
	{
		

		if($this->input->post('reset')==1)
		{
			$this->load->library('form_validation');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			if($this->form_validation->run() == FALSE)
			{
				$data['error'] = array();
				$data['error'] = 'E-mail no valido';
				$this->load->view('forgot_pass',$data);
			}
			else
			{
				$this->load->model('usuarios_model');
				$reset = $this->usuarios_model->forgot_pass();

				if($reset)
				{
				
					$data['success'] = array();
					$data['success'] = 'Restablecimiento de contraseña enviado.';
					$this->load->view('forgot_pass',$data);
				}
			}
		}
		else
		{
			$this->load->view('forgot_pass');
		}
		
	}
	
	function create_member()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules

		$this->form_validation->set_rules('nombre', 'Nombre', 'trim|required');
		$this->form_validation->set_rules('apellido', 'Apellido', 'trim|required');
		$this->form_validation->set_rules('dni', 'DNI', 'trim|required|is_unique[usuarios.dni]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[usuarios.email]');
		$this->form_validation->set_rules('fecha_nacimiento', 'Fecha de nacimiento', 'trim|required');
		$this->form_validation->set_rules('ciudad_nacimiento', 'Ciudad de nacimiento', 'trim|required');
		$this->form_validation->set_rules('edad', 'Edad', 'trim|required');
		$this->form_validation->set_rules('genero', 'Genero', 'trim|required');
		$this->form_validation->set_rules('carrera', 'Carrera', 'trim|required');
		$this->form_validation->set_rules('recursa', 'Recursa', 'trim|required');
	
		
		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('signup_form');
		}
		
		else
		{			
			$this->load->model('usuarios_model');
			
			if($query = $this->usuarios_model->create_member())
			{
				/*$data['main_content'] = 'signup_successful';
				$this->load->view('includes/template', $data);*/
				$this->load->view('signup_successful');
			}
			else
			{
				$this->load->view('signup_form');			
			}
		}
		
	}


	function is_logged_in()
	{
		return $is_logged_in = $this->session->userdata('is_logged_in');

		/*if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}*/		
	}	
	
	function logout()
	{
		$this->session->sess_destroy();
		$this->index();
	}
	

}