<h1>Congrats!</h1>
<p>Sus datos han sido actualizados. Por favor Conectese nuevamente <?php echo anchor('login/logout', 'Conectarse');?></p>
