<?php echo form_open('home/registro') ?>
	<?php echo form_input('nombre') ?>
	<?php echo form_password('password') ?>
	<?php echo form_submit('submit','Enviar') ?>
<?php echo form_close() ?><br />
<?php var_dump($users) ?>
