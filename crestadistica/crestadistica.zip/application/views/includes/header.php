<!DOCTYPE html>

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>Sign Up!</title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css" media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'css/datepicker.css'?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'css/bootstrap.css'?>"/>
	<link rel="stylesheet/less" type="text/css" href="<?php echo base_url().'less/datepicker.less'?>" />
	
</head>
<body>