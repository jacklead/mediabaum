<?php

class Login extends MX_Controller {
	
	function index()
	{
		$data['main_content'] = 'login_form';
		$this->load->view('includes/template', $data);		
	}
	
	function validate_credentials()
	{		
		$this->load->model('usuarios_model');
		$query = $this->usuarios_model->validate();
		
		if($query) // if the user's credentials validated...
		{
			$name = $this->usuarios_model->get_name($this->input->post('dni'));
			$data = array(
				'dni' => $this->input->post('dni'),
				'is_logged_in' => true,
				'name' => $name,
			);

			if(is_numeric($query))
			{
				$data['is_admin'] = true;
				$this->session->set_userdata($data);
				redirect('admin');
			}
			else
			{
				$this->session->set_userdata($data);
				redirect('site/members_area');
			}

			
			
		}
		else // incorrect username or password
		{
			$this->index();
		}
	}	
	
	function signup()
	{
		$data['main_content'] = 'signup_form';
		$this->load->view('includes/template', $data);
	}
	
	function create_member()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules

		$this->form_validation->set_rules('nombre', 'Nombre', 'trim|required');
		$this->form_validation->set_rules('apellido', 'Apellido', 'trim|required');
		$this->form_validation->set_rules('dni', 'DNI', 'trim|required|is_unique[usuarios.dni]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[usuarios.email]');
		$this->form_validation->set_rules('fecha_nacimiento', 'Fecha de nacimiento', 'trim|required');
		$this->form_validation->set_rules('ciudad_nacimiento', 'Ciudad de nacimiento', 'trim|required');
		$this->form_validation->set_rules('edad', 'Edad', 'trim|required');
		$this->form_validation->set_rules('genero', 'Genero', 'trim|required');
		$this->form_validation->set_rules('carrera', 'Carrera', 'trim|required');
		$this->form_validation->set_rules('recursa', 'Recursa', 'trim|required');
	
		
		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('signup_form');
		}
		
		else
		{			
			$this->load->model('usuarios_model');
			
			if($query = $this->usuarios_model->create_member())
			{
				$data['main_content'] = 'signup_successful';
				$this->load->view('includes/template', $data);
			}
			else
			{
				$this->load->view('signup_form');			
			}
		}
		
	}
	
	function logout()
	{
		$this->session->sess_destroy();
		$this->index();
	}
	

}