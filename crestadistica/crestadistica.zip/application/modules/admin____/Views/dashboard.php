	<div class="row">
		<div class="span12">
			<h2>Dashboard</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut egestas pulvinar odio nec dignissim. Aenean vulputate, lorem condimentum sollicitudin blandit, leo elit fermentum mauris, eget congue nunc mi vel turpis. Donec consequat, tellus eu pretium semper, nibh lectus blandit eros, quis auctor</p>
		</div>
	</div>
