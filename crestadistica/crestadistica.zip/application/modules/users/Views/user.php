
	
	<div class="row">
		<div class="span12">
			<pre><?php var_dump($user); ?></pre>
		</div>
	</div>
