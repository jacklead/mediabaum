<?php

class Admin extends MX_Controller 
{
	function __construct()
	{
		$this->is_logged_in();
	}

	function index()
	{

		$this->admin_area();
		
	}

	function admin_area()
	{
		$this->load->model('usuarios_model');
		$data['usuarios'] = $this->usuarios_model->get_users();
		$this->load->view('admin_area', $data);
	}
	
	function another_page() // just for sample
	{
		echo 'good. you\'re logged in.';
	}
	
	function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$is_admin = $this->session->userdata('is_admin');
		
		if(!isset($is_logged_in) || $is_logged_in != true || $is_admin != true )
		{
			echo 'You don\'t have permission to access this page. <a href="../login">Login</a>';	
			die();		
		}		
	}
	function validate_admin($dni)
	{

	}	

}
