<!DOCTYPE html>

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>Panel de control</title>
</head>
<body>
	<h2>Welcome Back, <?php echo $this->session->userdata('name'); ?>!</h2>
     <p>Administrador.</p>
	<h3>Listado de usuarios</h3>
	<ul>
	<?php 
		foreach ($usuarios AS $key => $usuario): 
			$usuario['status'] == 0 ? $status = 'Inactivo' : $status = 'Activo';
			$usuario['recursa'] == 0 ? $recursa = 'No recursa' : $recursa = 'Recursa';
			switch ($usuario['rol']) {
				case 1:
					$rol = 'Admin';
					break;
				case 2:
					$rol = 'Tester';
					break;
				
				default:
					$rol = 'Estudiante';
					break;
			}
	?>
		<li>
			<div><?php echo $usuario['nombre']; ?></div>
			<div><?php echo $usuario['apellido']; ?></div>
			<div><?php echo $usuario['dni']; ?></div>
			<div><?php echo $usuario['email']; ?></div>
			<div><?php echo $usuario['fecha_nacimiento']; ?></div>
			<div><?php echo $usuario['ciudad_nacimiento']; ?></div>
			<div><?php echo $usuario['edad']; ?></div>
			<div><?php echo $usuario['genero']; ?></div>
			<div><?php echo $usuario['carrera']; ?></div>
			<div><?php echo $recursa; ?></div>
			<div><?php echo $status; ?></div>
			<div><?php echo $rol; ?></div>
		</li>
	<?php endforeach;?>	
	</ul>
	<h4><?php echo anchor('login/logout', 'Logout'); ?></h4>
</body>
</html>	